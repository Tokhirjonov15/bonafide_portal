'use strict';
function $(i){return document.getElementById(i);}

/* 접수 자동연동 */
chrome.storage.local.get(['enabled','triggers','url'],function(v){
  $('en').checked = v.enabled!==false;
  $('tg').value = (Array.isArray(v.triggers)&&v.triggers.length?v.triggers:['접수등록']).join(', ');
  $('url').value = v.url||'https://bonafide-portal.seoulgijibae.workers.dev/dongseon/';
});
$('saveRecv').onclick=function(){
  var triggers=$('tg').value.split(',').map(function(s){return s.trim();}).filter(Boolean);
  if(!triggers.length)triggers=['접수등록'];
  var url=($('url').value.trim())||'https://bonafide-portal.seoulgijibae.workers.dev/dongseon/';
  if(!/\/$/.test(url))url+='/';
  chrome.storage.local.set({enabled:$('en').checked, triggers:triggers, url:url}, function(){
    $('stRecv').textContent='✅ 저장되었습니다';
  });
};

/* 차트 열기 — 검색창 지정 */
function refreshSel(){ chrome.storage.local.get(['selector'],function(v){ $('cur').textContent=(v&&v.selector)||'(없음)'; }); }
refreshSel();
chrome.storage.onChanged.addListener(function(ch){ if(ch.selector){ refreshSel(); if(ch.selector.newValue)$('stChart').textContent='✅ 검색창 지정 완료'; } });
$('pick').onclick=function(){
  chrome.tabs.query({url:['https://bitplusaz.kr/*','https://*.bitplusaz.kr/*']}, function(tabs){
    if(!tabs||!tabs.length){ $('stChart').textContent='먼저 비트플러스(EMR) 탭을 열어주세요'; return; }
    chrome.tabs.update(tabs[0].id,{active:true}, function(){
      try{ chrome.windows.update(tabs[0].windowId,{focused:true}); }catch(e){}
      chrome.tabs.sendMessage(tabs[0].id,{type:'pickStart'});
      $('stChart').textContent='EMR 화면에서 병록번호 검색창을 클릭하세요';
      window.close();
    });
  });
};
$('clear').onclick=function(){ chrome.storage.local.remove('selector', function(){ $('stChart').textContent='지정을 초기화했습니다'; refreshSel(); }); };

/* 진료의 칸 지정 — 접수 시 진료의 전달 */
function refreshDr(){ chrome.storage.local.get(['doctorSel'],function(v){ $('curDr').textContent=(v&&v.doctorSel)||'(없음)'; }); }
refreshDr();
chrome.storage.onChanged.addListener(function(ch){ if(ch.doctorSel){ refreshDr(); if(ch.doctorSel.newValue)$('stDr').textContent='✅ 진료의 칸 지정 완료'; } });
$('pickDr').onclick=function(){
  chrome.tabs.query({url:['https://bitplusaz.kr/*','https://*.bitplusaz.kr/*']}, function(tabs){
    if(!tabs||!tabs.length){ $('stDr').textContent='먼저 비트플러스(EMR) 탭을 열어주세요'; return; }
    chrome.tabs.update(tabs[0].id,{active:true}, function(){
      try{ chrome.windows.update(tabs[0].windowId,{focused:true}); }catch(e){}
      chrome.tabs.sendMessage(tabs[0].id,{type:'pickDoctor'});
      $('stDr').textContent='EMR 접수화면에서 진료의 칸을 클릭하세요';
      window.close();
    });
  });
};
$('clearDr').onclick=function(){ chrome.storage.local.remove('doctorSel', function(){ $('stDr').textContent='지정을 초기화했습니다'; refreshDr(); }); };
