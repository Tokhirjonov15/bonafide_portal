/* 백그라운드 — 🩺 차트열기 요청을 받아 EMR 탭을 찾아(없으면 생성) 포커스하고 검색어 채우기 지시 */
'use strict';
var pending = {}; // 새로 연 EMR 탭 로드 완료 시 채울 mrn

function emrTabQuery(){ return { url:['https://bitplusaz.kr/*','https://*.bitplusaz.kr/*'] }; }

function routeToEmr(mrn){
  chrome.tabs.query(emrTabQuery(), function(tabs){
    if(tabs && tabs.length){
      var t=tabs[0];
      try{ chrome.windows.update(t.windowId,{focused:true}); }catch(e){}
      chrome.tabs.update(t.id,{active:true}, function(){
        setTimeout(function(){ try{ chrome.tabs.sendMessage(t.id,{type:'fill', mrn:mrn}); }catch(e){} }, 250);
      });
    }else{
      chrome.tabs.create({url:'https://bitplusaz.kr/'}, function(t){ if(t)pending[t.id]=mrn; });
    }
  });
}

chrome.runtime.onMessage.addListener(function(msg){
  if(msg && msg.type==='openChart' && msg.mrn) routeToEmr(String(msg.mrn));
  else if(msg && msg.type==='admitBoard' && msg.payload) routeToBoard(String(msg.url||'https://bonafide-portal.seoulgijibae.workers.dev/dongseon/'), String(msg.payload));
});

/* 접수 자동연동: 동선 탭의 해시(#add=)만 갱신 — 재로딩·포커스 이동·팝업 없음(앱이 hashchange로 수신).
   탭이 없으면 백그라운드 탭으로 생성. (EMR 인쇄 팝업과 클릭 제스처를 다투지 않게 하기 위한 구조) */
function routeToBoard(url, payload){
  var origin;
  try{ origin=new URL(url).origin; }catch(e){ origin='https://bonafide-portal.seoulgijibae.workers.dev'; }
  var target=url+'#add='+payload;
  chrome.tabs.query({url:origin+'/dongseon/*'}, function(tabs){
    if(tabs && tabs.length){
      chrome.tabs.update(tabs[0].id, {url:target});   // 같은 문서의 해시 변경 → 새로고침 없이 hashchange만 발생
    }else{
      chrome.tabs.create({url:target, active:false}); // 동선 탭이 없으면 조용히(백그라운드) 생성
    }
  });
}

chrome.tabs.onUpdated.addListener(function(tabId, info){
  if(info.status==='complete' && pending[tabId]!==undefined){
    var mrn=pending[tabId]; delete pending[tabId];
    setTimeout(function(){ try{ chrome.tabs.sendMessage(tabId,{type:'fill', mrn:mrn}); }catch(e){} }, 2500);
  }
});
