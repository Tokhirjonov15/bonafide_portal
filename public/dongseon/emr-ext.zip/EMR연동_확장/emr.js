/* 비트플러스(EMR) 페이지 — 통합 콘텐츠 스크립트 (모든 프레임)
   A) 접수등록 감지 → 환자정보를 동선관리 '환자 추가' 창으로 자동 전달
   B) 동선 🩺 요청 수신 → 지정 검색창에 병록번호 입력·검색 / 검색창 지정(픽) 모드 */
'use strict';

/* ===== 공통 유틸 ===== */
function toast(t){
  try{
    var b=document.createElement('div');
    b.textContent=t;
    b.style.cssText='position:fixed;right:16px;bottom:16px;z-index:2147483647;background:#111827;color:#f9fafb;font:600 13px/1.4 -apple-system,"Malgun Gothic",sans-serif;padding:11px 14px;border-radius:10px;box-shadow:0 8px 24px rgba(0,0,0,.4);max-width:340px';
    document.documentElement.appendChild(b);
    setTimeout(function(){ if(b.parentNode)b.remove(); }, 3500);
  }catch(e){}
}
function T(e){ return e ? String(e.value||'').trim() : ''; }
// 같은-출처 프레임 전체에서 탐색(비트플러스 다중 프레임 대응)
function allDocs(){
  var out=[];
  function add(d){ if(d&&out.indexOf(d)<0){ try{ if(d.querySelectorAll) out.push(d); }catch(e){} } }
  try{ add(window.top.document); }catch(e){}
  try{ (function walk(w){ for(var i=0;i<w.length;i++){ try{ add(w[i].document); walk(w[i]); }catch(e){} } })(window.top); }catch(e){}
  add(document);
  return out;
}
function A(sel){ var o=[]; allDocs().forEach(function(d){ try{ o=o.concat([].slice.call(d.querySelectorAll(sel))); }catch(e){} }); return o; }
function G(n){
  var l=A('input[name='+n+']').filter(function(e){ return T(e); });
  var e=l.filter(function(x){ return x.offsetParent!==null; })[0]||l[0];
  return T(e);
}

/* ===== A) 접수 자동연동 ===== */
// 진료의 칸 지정(pick) 셀렉터 + 동선관리가 알려준 진료의 명단을 동기 캐시(클릭 순간 동기 읽기)
var DOCTOR_SEL='', DOCTOR_NAMES=[];
try{
  chrome.storage.local.get(['doctorSel','doctorNames'], function(v){ if(v){ if(v.doctorSel)DOCTOR_SEL=v.doctorSel; if(Array.isArray(v.doctorNames))DOCTOR_NAMES=v.doctorNames; } });
  chrome.storage.onChanged.addListener(function(ch){ if(ch.doctorSel)DOCTOR_SEL=ch.doctorSel.newValue||''; if(ch.doctorNames&&Array.isArray(ch.doctorNames.newValue))DOCTOR_NAMES=ch.doctorNames.newValue; });
}catch(e){}
// 접수화면 어디든 나타난 '알려진 진료의 이름'을 찾음(동선관리 명단 기준) — 필드 구조와 무관하게 가장 확실
function findKnownDoctor(){
  if(!DOCTOR_NAMES.length)return '';
  var docs=allDocs();
  for(var di=0;di<docs.length;di++){
    var txt=''; try{ txt=(docs[di].body&&docs[di].body.innerText)||''; }catch(e){}
    if(!txt)continue;
    for(var i=0;i<DOCTOR_NAMES.length;i++){ var nm=String(DOCTOR_NAMES[i]||'').trim(); if(nm && txt.indexOf(nm)>=0) return nm; }
  }
  return '';
}
// 요소에서 표시값 읽기: select=선택된 옵션의 '이름'(코드 아님), input=value, 그 외=글자
function readVal(el){
  if(!el)return '';
  var tag=(el.tagName||'').toLowerCase();
  if(tag==='select'){ var o=el.options&&el.options[el.selectedIndex]; return o?String(o.text||o.value||'').trim():''; }
  if(tag==='input'||tag==='textarea'){ var iv=String(el.value||'').trim(); if(iv)return iv; var ph=String(el.getAttribute('placeholder')||'').trim(); return isPrompt(ph)?'':ph; }  // el-input: 값 없으면 placeholder(선택된 이름)
  return String(el.innerText||el.textContent||'').replace(/ /g,' ').trim();
}
// 요소의 '직접' 텍스트만(자식 요소 텍스트 제외)
function directText(el){ try{ var s=''; for(var i=0;i<el.childNodes.length;i++){ var n=el.childNodes[i]; if(n.nodeType===3)s+=n.nodeValue; } return s.replace(/[\s ]+/g,' ').trim(); }catch(e){ return ''; } }
// 이름처럼 보이는 값(숫자·시간·라벨 자체 제외, 10자 이하)
function looksName(v){ v=(v||'').trim(); return !!v && v.length<=10 && !/^[0-9\-:.\s]+$/.test(v) && !/진료의|담당의|의사|주치의|과장|원장님?$/.test(v); }
// 라벨 요소 옆(형제·표의 다음 셀)에서 값 찾기
function valueNear(el){
  var s=el.nextElementSibling, k=0;
  while(s && k<4){ var inp=s.querySelector&&s.querySelector('input,select'); var v=readVal(inp||s); if(looksName(v))return v; s=s.nextElementSibling; k++; }
  var td=el.closest&&el.closest('td,th');
  if(td){ var nx=td.nextElementSibling, j=0; while(nx&&j<3){ var inp2=nx.querySelector&&nx.querySelector('input,select'); var v2=readVal(inp2||nx); if(looksName(v2))return v2; nx=nx.nextElementSibling; j++; } }
  return '';
}
// "진료의/담당의" 라벨을 찾아 옆의 이름 값을 자동 인식
function findDoctorByLabel(){
  var labels=['진료의','담당의','진료의사','주치의','진료 의사','담당 의사','진료과의사'];
  var docs=allDocs();
  for(var di=0;di<docs.length;di++){
    var els; try{ els=docs[di].querySelectorAll('td,th,label,span,div,dt,li'); }catch(e){ continue; }
    for(var i=0;i<els.length;i++){ var t=directText(els[i]).replace(/[:\s]+$/,''); if(labels.indexOf(t)>=0){ var v=valueNear(els[i]); if(v)return v; } }
  }
  return '';
}
// 첫 요소(보이는 것 우선)
function firstEl(sel){ var l=A(sel); return l.filter(function(x){return x.offsetParent!==null;})[0]||l[0]||null; }
function isPrompt(s){ s=(s||'').trim(); return !s || /^(선택|선택하세요|선택하십시오|없음|전체|미지정|검색)$/.test(s); }
// 비트플러스 진료의 칸: 이름이 value가 아니라 placeholder에 들어옴(el-input). "선택" 등 프롬프트는 제외
function readDoctorInput(){
  var el=firstEl('input[name=ocmdtrcod]'); if(!el)return '';
  var val=String(el.value||'').trim();
  if(looksName(val) && !isPrompt(val)) return val;                       // 값에 이름이 있으면
  var ph=String(el.getAttribute('placeholder')||'').trim();
  if(looksName(ph) && !isPrompt(ph)) return ph;                         // 선택된 진료의명이 placeholder에 표시됨
  return '';
}
// 진료의 추출: ①지정한 칸 → ②ocmdtrcod(값/placeholder) → ③이름형 필드 → ④"진료의" 라벨 옆 → ⑤명단 자동인식 → ⑥코드
function extractDoctor(){
  if(DOCTOR_SEL){
    var el=null; allDocs().forEach(function(d){ if(el)return; try{ var e=d.querySelector(DOCTOR_SEL); if(e)el=e; }catch(x){} });
    var v=readVal(el); if(looksName(v)&&!isPrompt(v))return v;
  }
  var d0=readDoctorInput(); if(d0)return d0;   // ★ 비트플러스 진료의 칸(placeholder에 이름)
  var nameCands=['ocmdtrnam','ocmdtrname','pbsdtrnam','dtrnam','drnam','docnam','ocmdrnam'];
  for(var i=0;i<nameCands.length;i++){ var nv=G(nameCands[i]); if(looksName(nv)&&!isPrompt(nv)) return nv; }  // 이름형 우선
  var byLbl=findDoctorByLabel(); if(byLbl)return byLbl;   // "진료의" 라벨 옆 값 자동
  var known=findKnownDoctor(); if(known)return known;     // 동선관리 명단에 있는 이름을 화면에서 자동 인식
  return '';
}
var CFG={ enabled:true, triggers:['접수등록'], url:'https://bonafide-portal.seoulgijibae.workers.dev/dongseon/' };
try{
  chrome.storage.local.get(['enabled','triggers','url'],function(v){
    if(v){ if(v.enabled===false)CFG.enabled=false;
      if(Array.isArray(v.triggers)&&v.triggers.length)CFG.triggers=v.triggers;
      if(v.url)CFG.url=v.url; }
  });
  chrome.storage.onChanged.addListener(function(ch){
    if(ch.enabled)CFG.enabled=ch.enabled.newValue!==false;
    if(ch.triggers&&Array.isArray(ch.triggers.newValue))CFG.triggers=ch.triggers.newValue;
    if(ch.url&&ch.url.newValue)CFG.url=ch.url.newValue;
  });
}catch(e){}
// 예약 판별: 예약대기 그리드(col-id 'OcmAcpDtm'이 있는 행)에서 이 환자번호(OcmChtNum) 찾기 → 있으면 예약시간 반환
function findRsvTime(cht){
  cht=String(cht||'').replace(/\D/g,'');
  if(!cht)return '';
  var rows=[];
  allDocs().forEach(function(d){ try{ rows=rows.concat([].slice.call(d.querySelectorAll('.ag-row'))); }catch(e){} });
  for(var i=0;i<rows.length;i++){
    var cells=rows[i].querySelectorAll('.ag-cell'), dtm='', num='';
    for(var j=0;j<cells.length;j++){
      var col=cells[j].getAttribute('col-id'), val=(cells[j].textContent||'').trim();
      if(col==='OcmAcpDtm')dtm=val;                    // 예약대기 그리드에만 있는 열 = 예약시각
      else if(col==='OcmChtNum')num=val.replace(/\D/g,'');
    }
    if(dtm && num===cht){ var m=/([0-9]{1,2}:[0-9]{2})/.exec(dtm); if(m)return m[1]; }
  }
  return '';
}
function extractPatient(){
  var L=A('input[name=pbspatnam]').filter(function(e){ return T(e); });
  var nam=L.filter(function(e){ return e.offsetParent!==null; })[0]||L[0];
  if(!nam)return null;
  var name=T(nam);
  var r1=G('pbsresnum1'), r2=G('pbsresnum2');
  var mrn=G('pbschtnum'); if(!/^[0-9]+$/.test(mrn)){ var c=G('chtnum'); mrn=/^[0-9]+$/.test(c)?c:''; }
  var rrn7=(/^[0-9]{6}$/.test(r1)&&/^[0-9]/.test(r2))?(r1+'-'+r2.charAt(0)):(/^[0-9]{6}$/.test(r1)?r1:'');
  var recv=G('ocmacptime'); if(!/^[0-9]{1,2}:[0-9]{2}$/.test(recv))recv='';
  var tel=(G('pbscelphn0')+G('pbscelphn1')+G('pbscelphn2')).replace(/[^0-9]/g,''); if(tel.length<10)tel='';
  var dr=extractDoctor();   // 진료의(담당의사) — 지정 칸 우선, 이름형 후보 폴백
  // 예약대기에 있으면 예약(k=r, 예약시간), 없으면 워크인(k=w, 접수시간)
  var kind='w', rsv=findRsvTime(mrn);
  if(rsv){ kind='r'; recv=rsv; }
  return { name:name, mrn:mrn, rrn7:rrn7, recv:recv, tel:tel, dr:dr, k:kind };
}
var lastKey='', lastAt=0;
document.addEventListener('click', function(ev){
  if(!CFG.enabled)return;
  var el=ev.target&&ev.target.closest?ev.target.closest('button,a,[role=button],input[type=button],input[type=submit],span,div'):null;
  if(!el)return;
  var txt=String(el.textContent||el.value||'').replace(/\s+/g,'');
  if(!txt||txt.length>12)return;
  var hit=CFG.triggers.some(function(t){ return txt===String(t).replace(/\s+/g,''); });
  if(!hit)return;
  var p=extractPatient();
  if(!p||!p.name)return;
  var key=(p.mrn||p.name)+'|'+p.recv;
  if(key===lastKey && Date.now()-lastAt<4000)return;
  lastKey=key; lastAt=Date.now();
  try{
    var payload=btoa(unescape(encodeURIComponent(JSON.stringify(p))));
    // ★ 클릭 제스처 안에서 window.open을 쓰면 EMR 자체의 인쇄 팝업(처방전 등)이 팝업 예산을 뺏겨 차단됨
    //   → 백그라운드로 넘겨 이미 열린 동선 탭의 주소(#add=)만 갱신(팝업·포커스 이동 없음). 탭 없으면 백그라운드로 생성.
    chrome.runtime.sendMessage({type:'admitBoard', url:CFG.url, payload:payload});
  }catch(e){}
}, true);

/* ===== B) 차트 열기(검색창 채우기 + 지정) ===== */
function cssEsc(s){ return (window.CSS&&CSS.escape)?CSS.escape(s):String(s).replace(/[^a-zA-Z0-9_-]/g,'\\$&'); }
function isUnique(sel){ try{ return document.querySelectorAll(sel).length===1; }catch(e){ return false; } }
function cssPath(el){
  var parts=[], node=el;
  while(node && node.nodeType===1 && node.tagName && node.tagName.toLowerCase()!=='html'){
    if(node.id){ parts.unshift('#'+cssEsc(node.id)); break; }
    var tag=node.tagName.toLowerCase(), parent=node.parentNode, part=tag;
    if(parent){
      var sib=parent.children, n=0, idx=0;
      for(var k=0;k<sib.length;k++){ if(sib[k].tagName===node.tagName){ n++; if(sib[k]===node) idx=n; } }
      if(n>1) part+=':nth-of-type('+idx+')';
    }
    parts.unshift(part);
    node=parent;
  }
  return parts.join(' > ');
}
function selectorFor(el){
  if(el.id){ var s='#'+cssEsc(el.id); if(isUnique(s)) return s; }
  var nm=el.getAttribute&&el.getAttribute('name');
  if(nm){ var s2=el.tagName.toLowerCase()+'[name="'+nm+'"]'; if(isUnique(s2)) return s2; }
  var ph=el.getAttribute&&el.getAttribute('placeholder');
  if(ph){ var s3=el.tagName.toLowerCase()+'[placeholder="'+ph.replace(/"/g,'\\"')+'"]'; if(isUnique(s3)) return s3; }
  var p=cssPath(el);
  if(p && (function(){try{return document.querySelector(p)===el;}catch(e){return false;}})()) return p;
  return null;
}
function setNativeValue(el, value){
  try{
    var proto=Object.getPrototypeOf(el);
    var desc=Object.getOwnPropertyDescriptor(proto,'value');
    if(desc&&desc.set) desc.set.call(el,value); else el.value=value;
  }catch(e){ el.value=value; }
}
function fillChart(mrn){
  chrome.storage.local.get(['selector'], function(v){
    var sel=v&&v.selector;
    if(!sel){ toast('검색창이 지정되지 않았습니다 — 확장 아이콘 → "검색창 지정"을 먼저 하세요'); return; }
    var el=null; try{ el=document.querySelector(sel); }catch(e){}
    if(!el) return;                          // 다른 프레임이 처리
    el.focus();
    setNativeValue(el, mrn);
    el.dispatchEvent(new Event('input',{bubbles:true}));
    el.dispatchEvent(new Event('change',{bubbles:true}));
    ['keydown','keypress','keyup'].forEach(function(type){
      el.dispatchEvent(new KeyboardEvent(type,{key:'Enter',code:'Enter',keyCode:13,which:13,bubbles:true}));
    });
    toast('🩺 차트 조회: '+mrn);
  });
}
var picking=false, pickKind='search';
function startPick(kind){
  if(picking)return; picking=true; pickKind=(kind==='doctor')?'doctor':'search';
  // 최상위뿐 아니라 같은-출처 프레임 전체에 리스너 부착(비트플러스 다중 프레임 대응) — addEventListener는 동일 리스너 중복 무시
  allDocs().forEach(function(d){ try{ d.addEventListener('click', onPick, true); d.addEventListener('keydown', onEsc, true); }catch(e){} });
  toast(pickKind==='doctor' ? 'EMR 접수화면에서 진료의가 표시된 칸(또는 글자)을 클릭하세요 (취소: ESC)' : 'EMR에서 병록번호 검색창을 클릭하세요 (취소: ESC)');
}
function stopPick(){ picking=false; allDocs().forEach(function(d){ try{ d.removeEventListener('click',onPick,true); d.removeEventListener('keydown',onEsc,true); }catch(e){} }); }
function onEsc(e){ if(e.key==='Escape'){ stopPick(); toast('지정 취소'); } }
function onPick(e){
  if(!picking)return;
  var el=e.target;
  if(pickKind==='doctor'){
    if(!el||!el.tagName||/^(html|body)$/i.test(el.tagName)){ toast('진료의가 표시된 칸(또는 글자)을 클릭하세요'); return; }
  }else{
    if(!el||!/^(input|textarea)$/i.test(el.tagName)){ toast('입력칸(검색창)을 클릭하세요'); return; }
  }
  e.preventDefault(); e.stopPropagation();
  var sel=selectorFor(el);
  if(!sel){ toast('이 칸은 지정 불가 — 다른 칸을 시도하세요'); return; }
  if(pickKind==='doctor'){ chrome.storage.local.set({doctorSel:sel}, function(){ toast('✅ 진료의 칸 지정 완료 — 이제 접수 시 진료의가 함께 전달됩니다'); }); }
  else { chrome.storage.local.set({selector:sel}, function(){ toast('✅ 검색창 지정 완료'); }); }
  stopPick();
}

chrome.runtime.onMessage.addListener(function(m){
  if(!m)return;
  if(m.type==='fill') fillChart(String(m.mrn||''));
  else if(m.type==='pickStart') startPick('search');
  else if(m.type==='pickDoctor') startPick('doctor');
});
