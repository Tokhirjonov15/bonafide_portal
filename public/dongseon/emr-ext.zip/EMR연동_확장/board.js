/* 동선관리 페이지 — 확장 설치 표식 + 🩺 차트열기 요청 전달 */
'use strict';
try{ document.documentElement.setAttribute('data-emr-ext','1'); }catch(e){}
window.addEventListener('message', function(e){
  if(e.source!==window) return;
  var d=e.data;
  if(d && d.__emr==='open' && d.mrn){
    try{ chrome.runtime.sendMessage({type:'openChart', mrn:String(d.mrn)}); }catch(err){}
  }
  else if(d && d.__emr==='doctors' && Array.isArray(d.list)){   // 동선관리가 알려준 진료의 명단 → 확장 저장(접수 시 진료의 자동 인식용)
    try{ chrome.storage.local.set({doctorNames: d.list.filter(Boolean).slice(0,300)}); }catch(err){}
  }
});
